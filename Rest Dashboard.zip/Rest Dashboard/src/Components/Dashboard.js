// Navbar.js

import React from 'react';
import Navbar from './Navbar';
import UserDetails from './UserDetails';
import CurrentOrders from './CurrentOrders';


const Dashboard = () => {
  return (
  <div>
    <UserDetails></UserDetails>
  </div>
  );
}

export default Dashboard;
