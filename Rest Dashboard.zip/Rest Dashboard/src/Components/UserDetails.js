// UserDetails.js

import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';

const UserDetails = () => {
  const [userDetails, setUserDetails] = useState(null);

  useEffect(() => {
    // Fetch user details from the backend API
    // Example: fetch('/api/user-details').then(response => response.json()).then(data => setUserDetails(data));
  }, []);

  return (
  <div><Navbar></Navbar>
    <div className="container mx-auto mt-8">
     
      <h2 className="text-2xl font-bold mb-4">User Details</h2>
      {userDetails ? (
        <div>
          <p>Name: {userDetails.name}</p>
          <p>Email: {userDetails.email}</p>
          {/* Add more user details as needed */}
        </div>
      ) : (
        <p>Loading user details...</p>
      )}
    </div>
    </div>
  );
}

export default UserDetails;
