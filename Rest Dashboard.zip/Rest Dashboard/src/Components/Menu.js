import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';
import AddMenuForm from './AddMenuForm';

const Menu = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [isFormOpen, setFormOpen] = useState(false);

  useEffect(() => {
    // Fetch menu items from the backend API
    // Example: fetch('/api/menu').then(response => response.json()).then(data => setMenuItems(data));
    // Replace the placeholder API call with your actual API call
    const sampleData = [
      { id: 1, name: 'Cheeseburger', price: 8.99,  },
      { id: 2, name: 'Margherita Pizza', price: 12.50, },
      // Add more sample data or replace it with actual data from your API
    ];
    setMenuItems(sampleData);
  }, []);

  const handleAddNewMenu = (newMenuItem) => {
    // Add new menu item logic (e.g., make API call to add new menu item)
    // For simplicity, just updating the state here
    setMenuItems((prevMenuItems) => [...prevMenuItems, { id: prevMenuItems.length + 1, ...newMenuItem }]);
    setFormOpen(false);
  };

  const handleCancelForm = () => {
    setFormOpen(false);
  };

  return (
    <div>
      <Navbar />
      <div className="container mx-auto mt-8">
        <div className="flex justify-around items-center mb-4 ">
          <h2 className="text-2xl font-bold ">Menu</h2>
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded focus:outline-none"
            onClick={() => setFormOpen(true)}
          >
            Add New Menu
          </button>
        </div>

       
        {menuItems.length > 0 ? (
          <table className="min-w-full border border-gray-300">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2">ID</th>
                <th className="border border-gray-300 px-4 py-2">Name</th>
                <th className="border border-gray-300 px-4 py-2">Price</th>
         
              </tr>
            </thead>
            <tbody className='text-center'>
              {menuItems.map((item) => (
                <tr key={item.id}>
                  <td className="border border-gray-300 px-4 py-2">{item.id}</td>
                  <td className="border border-gray-300 px-4 py-2">{item.name}</td>
                  <td className="border border-gray-300 px-4 py-2">{item.price}</td>
              
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No menu items available.</p>
        )}
      </div>
      {isFormOpen && (
          <AddMenuForm onSubmit={handleAddNewMenu} onCancel={handleCancelForm} />
        )}

    </div>
  );
};

export default Menu;
