// Menu.js

import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';

const Menu = () => {
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    // Fetch menu items from the backend API
    // Example: fetch('/api/menu').then(response => response.json()).then(data => setMenuItems(data));
    // Replace the placeholder API call with your actual API call
    const sampleData = [
      { id: 1, name: 'Cheeseburger', price: 8.99, description: 'Juicy beef patty with melted cheese' },
      { id: 2, name: 'Margherita Pizza', price: 12.50, description: 'Classic pizza with tomato and mozzarella' },
      // Add more sample data or replace it with actual data from your API
    ];
    setMenuItems(sampleData);
  }, []);

  return (
    <div><Navbar/>
    <div className="container mx-auto mt-8">
      <h2 className="text-2xl font-bold mb-4">Menu</h2>
      {menuItems.length > 0 ? (
        <table className="min-w-full border border-gray-300">
          <thead>
            <tr>
              <th className="border border-gray-300 px-4 py-2">ID</th>
              <th className="border border-gray-300 px-4 py-2">Name</th>
              <th className="border border-gray-300 px-4 py-2">Price</th>
              <th className="border border-gray-300 px-4 py-2">Description</th>
            </tr>
          </thead>
          <tbody>
            {menuItems.map(item => (
              <tr key={item.id}>
                <td className="border border-gray-300 px-4 py-2">{item.id}</td>
                <td className="border border-gray-300 px-4 py-2">{item.name}</td>
                <td className="border border-gray-300 px-4 py-2">{item.price}</td>
                <td className="border border-gray-300 px-4 py-2">{item.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No menu items available.</p>
      )}
    </div></div>
  );
}

export default Menu;
